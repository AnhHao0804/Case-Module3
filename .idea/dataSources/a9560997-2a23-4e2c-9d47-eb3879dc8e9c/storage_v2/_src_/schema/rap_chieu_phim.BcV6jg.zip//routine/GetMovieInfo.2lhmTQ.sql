create
    definer = root@localhost procedure GetMovieInfo(IN p_movie_id int)
BEGIN
    SELECT * FROM Movies
    WHERE movie_id = p_movie_id;
END;

