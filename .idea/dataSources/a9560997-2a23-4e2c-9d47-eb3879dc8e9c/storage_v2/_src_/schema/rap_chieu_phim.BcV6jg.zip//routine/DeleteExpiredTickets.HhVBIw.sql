create
    definer = root@localhost procedure DeleteExpiredTickets()
BEGIN
    DELETE FROM TransactionHistory
    WHERE status = 'Đã đặt' AND expiry_time < DATE_ADD(NOW(), INTERVAL 50 MINUTE);
    
    DELETE t
    FROM Tickets t
    -- JOIN TransactionHistory th ON t.ticket_id =  th.ticket_id
    LEFT JOIN TransactionHistory th ON t.ticket_id =  th.ticket_id
	WHERE th.ticket_id IS NULL;
    -- WHERE t.ticket_id NOT IN (SELECT th.ticket_id FROM TransactionHistory);
END;

