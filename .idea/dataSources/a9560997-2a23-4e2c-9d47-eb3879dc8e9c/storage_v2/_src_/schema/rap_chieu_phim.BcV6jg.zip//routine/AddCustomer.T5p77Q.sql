create
    definer = root@localhost procedure AddCustomer(IN p_phone_number varchar(15), IN p_full_name varchar(100),
                                                   IN p_email varchar(100), IN p_username varchar(50))
BEGIN
    INSERT INTO Customers (phone_number, full_name, email, username)
    VALUES (p_phone_number, p_full_name, p_email, p_username);
    
    INSERT INTO UserRoles (username, role_id)
    VALUES (p_username, (SELECT role_id FROM Roles WHERE role_name = 'ROLE_USER'));
END;

