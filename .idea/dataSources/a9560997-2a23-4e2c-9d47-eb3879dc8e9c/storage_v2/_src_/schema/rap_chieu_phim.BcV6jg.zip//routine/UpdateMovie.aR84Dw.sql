create
    definer = root@localhost procedure UpdateMovie(IN p_movie_id int, IN p_title varchar(100), IN p_genre varchar(50),
                                                   IN p_duration int, IN p_image_url varchar(255),
                                                   IN p_trailer_url varchar(255), IN p_description text)
BEGIN
    UPDATE Movies
    SET title = p_title,
        genre = p_genre,
        duration = p_duration,
        image_url = p_image_url,
        trailer_url = p_trailer_url,
        description = p_description
    WHERE movie_id = p_movie_id;
END;

