create
    definer = root@localhost procedure DeleteAccount(IN p_username varchar(50))
BEGIN
    -- Xóa vai trò của tài khoản
    DELETE FROM UserRoles
    WHERE username = p_username;
    
    -- Xóa tài khoản
    DELETE FROM Users
    WHERE username = p_username;
END;

