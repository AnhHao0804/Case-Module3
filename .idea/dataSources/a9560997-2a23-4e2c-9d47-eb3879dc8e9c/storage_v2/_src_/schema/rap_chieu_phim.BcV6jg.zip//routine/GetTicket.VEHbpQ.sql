create
    definer = root@localhost procedure GetTicket(IN p_ticket_id int)
BEGIN
    SELECT * FROM Tickets
    WHERE ticket_id = p_ticket_id;
END;

