create
    definer = root@localhost procedure DeleteShowtime(IN p_showtime_id int)
BEGIN
    DELETE FROM Showtimes
    WHERE showtime_id = p_showtime_id;
END;

