create
    definer = root@localhost procedure UpdateShowtime(IN p_showtime_id int, IN p_movie_id int, IN p_duration int,
                                                      IN p_start_time datetime, IN p_end_time datetime,
                                                      IN p_theater_id int, IN p_room_id int, IN p_seats int)
BEGIN
    UPDATE Showtimes
    SET movie_id = p_movie_id,
        duration = p_duration,
        start_time = p_start_time,
        end_time = p_end_time,
        theater_id = p_theater_id,
        room_id = p_room_id,
        seats = p_seats
    WHERE showtime_id = p_showtime_id;
END;

