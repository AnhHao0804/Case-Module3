create
    definer = root@localhost procedure DeleteEmployee(IN p_cccd varchar(20))
BEGIN
    DECLARE v_username VARCHAR(50);

    -- Lấy tên đăng nhập của nhân viên từ cccd
    SELECT username INTO v_username
    FROM Employees
    WHERE cccd = p_cccd;

    -- Xóa nhân viên
    DELETE FROM Employees
    WHERE cccd = p_cccd;

    -- Xóa tài khoản người dùng và vai trò
    DELETE FROM Users
    WHERE username = v_username;

    DELETE FROM UserRoles
    WHERE username = v_username;
END;

