create
    definer = root@localhost procedure DeleteCustomer(IN p_phone_number varchar(15))
BEGIN
    DELETE FROM Customers
    WHERE phone_number = p_phone_number;
    
    -- Xóa thông tin tài khoản và vai trò của khách hàng
    DELETE FROM Users
    WHERE username = (SELECT username FROM Customers WHERE phone_number = p_phone_number);
    
    DELETE FROM UserRoles
    WHERE username = (SELECT username FROM Customers WHERE phone_number = p_phone_number);
END;

