create
    definer = root@localhost procedure TrackTicketStatus(IN p_showtime_id int)
BEGIN
    SELECT
        status,
        COUNT(*) AS count
    FROM Tickets
    WHERE showtime_id = p_showtime_id
    GROUP BY status;
END;

