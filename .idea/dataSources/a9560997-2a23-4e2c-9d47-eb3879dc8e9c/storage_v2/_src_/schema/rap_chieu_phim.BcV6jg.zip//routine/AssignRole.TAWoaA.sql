create
    definer = root@localhost procedure AssignRole(IN p_username varchar(50), IN p_role_name varchar(50))
BEGIN
    DECLARE v_role_id INT;
    
    -- Lấy role_id dựa trên role_name
    SELECT role_id INTO v_role_id
    FROM Roles
    WHERE role_name = p_role_name;
    
    -- Cấp vai trò cho tài khoản
    INSERT IGNORE INTO UserRoles (username, role_id)
    VALUES (p_username, v_role_id);
END;

