create
    definer = root@localhost procedure UpdateTicket(IN p_ticket_id int, IN p_price decimal(10, 2),
                                                    IN p_ticket_type varchar(50), IN p_seat_number varchar(10),
                                                    IN p_start_time datetime,
                                                    IN p_status enum ('Đã thanh toán', 'Đã đặt', 'Đã kết thúc'))
BEGIN
    UPDATE Tickets
    SET price = p_price,
        ticket_type = p_ticket_type,
        seat_number = p_seat_number,
        start_time = p_start_time,
        status = p_status
    WHERE ticket_id = p_ticket_id;
END;

