create
    definer = root@localhost procedure AddUser(IN p_username varchar(50), IN p_password varchar(255),
                                               IN p_role_name varchar(50))
BEGIN
    DECLARE v_role_id INT;
    DECLARE v_role_count INT;
    
    SELECT role_id INTO v_role_id
    FROM Roles
    WHERE role_name = p_role_name;
    
    SELECT COUNT(*) INTO v_role_count
    FROM Users
    WHERE username = p_username;
    
    IF v_role_count = 0 THEN
        INSERT INTO Users (username, password)
        VALUES (p_username, p_password);
        
        INSERT INTO UserRoles (username, role_id)
        VALUES (p_username, v_role_id);
    ELSE
        SELECT 'Tài khoản đã tồn tại' AS AccountError;
    END IF;
END;

