create
    definer = root@localhost procedure GetUpcomingMovies()
BEGIN
    SELECT m.movie_id, m.title, m.genre, m.duration, m.image_url, m.trailer_url, m.description
    FROM Movies m
    JOIN Showtimes s ON m.movie_id = s.movie_id
    WHERE s.start_time > NOW()
    GROUP BY m.movie_id
    ORDER BY MIN(s.start_time);
END;

