create
    definer = root@localhost procedure AddShowtime(IN p_movie_id int, IN p_duration int, IN p_start_time datetime,
                                                   IN p_end_time datetime, IN p_theater_id int, IN p_room_id int,
                                                   IN p_seats int)
BEGIN
    INSERT INTO Showtimes (movie_id, duration, start_time, end_time, theater_id, room_id, seats)
    VALUES (p_movie_id, p_duration, p_start_time, p_end_time, p_theater_id, p_room_id, p_seats);
END;

