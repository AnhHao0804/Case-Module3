create
    definer = root@localhost procedure DeleteTicket(IN p_ticket_id int)
BEGIN
    DELETE FROM Tickets
    WHERE ticket_id = p_ticket_id;
END;

