create
    definer = root@localhost procedure GetShowtime(IN p_showtime_id int)
BEGIN
    SELECT * FROM Showtimes
    WHERE showtime_id = p_showtime_id;
END;

