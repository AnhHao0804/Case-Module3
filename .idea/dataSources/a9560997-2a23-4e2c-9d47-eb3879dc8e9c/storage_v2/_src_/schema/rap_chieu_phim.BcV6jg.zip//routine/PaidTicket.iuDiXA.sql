create
    definer = root@localhost procedure PaidTicket(IN p_ticket_id int)
BEGIN
    UPDATE Tickets
    SET status = 'Đã thanh toán'
    WHERE ticket_id = p_ticket_id;
    
    UPDATE TransactionHistory
    SET status = 'Đã thanh toán'
    WHERE ticket_id = p_ticket_id;
END;

