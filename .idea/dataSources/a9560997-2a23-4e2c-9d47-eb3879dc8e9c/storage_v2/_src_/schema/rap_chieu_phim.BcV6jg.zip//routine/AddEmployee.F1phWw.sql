create
    definer = root@localhost procedure AddEmployee(IN p_cccd varchar(20), IN p_phone_number varchar(15),
                                                   IN p_full_name varchar(100), IN p_email varchar(100),
                                                   IN p_username varchar(50), IN p_password varchar(255))
BEGIN
    -- Thêm thông tin nhân viên vào bảng Employees
    INSERT INTO Employees (cccd, phone_number, full_name, email)
    VALUES (p_cccd, p_phone_number, p_full_name, p_email);
    
    -- Thêm tài khoản người dùng với ROLE_EMPLOYEE
    INSERT INTO Users (username, password)
    VALUES (p_username, p_password);
    
    INSERT INTO UserRoles (username, role_id)
    VALUES (p_username, (SELECT role_id FROM Roles WHERE role_name = 'ROLE_EMPLOYEE'));
END;

