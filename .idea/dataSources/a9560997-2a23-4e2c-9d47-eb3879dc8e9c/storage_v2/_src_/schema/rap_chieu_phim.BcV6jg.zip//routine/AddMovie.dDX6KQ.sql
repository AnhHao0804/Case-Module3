create
    definer = root@localhost procedure AddMovie(IN p_title varchar(100), IN p_genre varchar(50), IN p_duration int,
                                                IN p_image_url varchar(255), IN p_trailer_url varchar(255),
                                                IN p_description text)
BEGIN
    INSERT INTO Movies (title, genre, duration, image_url, trailer_url, description)
    VALUES (p_title, p_genre, p_duration, p_image_url, p_trailer_url, p_description);
END;

