create
    definer = root@localhost procedure PurchaseTicket(IN p_showtime_id int, IN p_price decimal(10, 2),
                                                      IN p_ticket_type varchar(50), IN p_seat_number varchar(10),
                                                      IN p_start_time datetime, IN p_customer_phone varchar(15))
BEGIN
    DECLARE v_ticket_id INT;
    DECLARE v_status ENUM('Đã thanh toán', 'Đã đặt', 'Đã kết thúc');
    DECLARE v_expiry_time DATETIME;
    
    IF NOT EXISTS (SELECT 1 FROM Tickets WHERE showtime_id = p_showtime_id AND seat_number = p_seat_number) THEN
        SET v_status = 'Đã đặt';
        INSERT INTO Tickets (showtime_id, price, ticket_type, seat_number, start_time, status)
        VALUES (p_showtime_id, p_price, p_ticket_type, p_seat_number, p_start_time, v_status);
        
        SET v_ticket_id = LAST_INSERT_ID();
        SET v_expiry_time = DATE_ADD(NOW(), INTERVAL 30 MINUTE);
        
        INSERT INTO TransactionHistory (ticket_id, customer_phone, transaction_time, expiry_time, status)
        VALUES (v_ticket_id, p_customer_phone, NOW(), v_expiry_time, v_status);
    ELSE
        SELECT 'Vé đã tồn tại hoặc đã được đặt' AS TicketError;
    END IF;
END;

