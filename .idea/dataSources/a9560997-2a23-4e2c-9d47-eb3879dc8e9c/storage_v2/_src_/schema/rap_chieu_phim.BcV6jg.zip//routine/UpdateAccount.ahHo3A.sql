create
    definer = root@localhost procedure UpdateAccount(IN p_username varchar(50), IN p_password varchar(255))
BEGIN
    -- Cập nhật thông tin tài khoản
    UPDATE Users
    SET password = p_password
    WHERE username = p_username;
END;

