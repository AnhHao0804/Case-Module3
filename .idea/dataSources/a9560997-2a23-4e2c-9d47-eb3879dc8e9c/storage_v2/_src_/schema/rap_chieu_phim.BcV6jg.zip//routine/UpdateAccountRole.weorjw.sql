create
    definer = root@localhost procedure UpdateAccountRole(IN p_username varchar(50), IN p_new_role_name varchar(50))
BEGIN
    DECLARE v_new_role_id INT;
    
    -- Lấy role_id dựa trên role_name mới
    SELECT role_id INTO v_new_role_id
    FROM Roles
    WHERE role_name = p_new_role_name;
    
    -- Xóa vai trò cũ của tài khoản
    DELETE FROM UserRoles
    WHERE username = p_username;
    
    -- Cấp vai trò mới cho tài khoản
    INSERT INTO UserRoles (username, role_id)
    VALUES (p_username, v_new_role_id);
END;

