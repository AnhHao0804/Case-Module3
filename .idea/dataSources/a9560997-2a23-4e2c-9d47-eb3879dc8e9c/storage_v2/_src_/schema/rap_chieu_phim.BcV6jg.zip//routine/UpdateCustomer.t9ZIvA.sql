create
    definer = root@localhost procedure UpdateCustomer(IN p_phone_number varchar(15), IN p_full_name varchar(100),
                                                      IN p_email varchar(100), IN p_username varchar(50))
BEGIN
    UPDATE Customers
    SET full_name = p_full_name,
        email = p_email,
        username = p_username
    WHERE phone_number = p_phone_number;
END;

