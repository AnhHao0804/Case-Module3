create
    definer = root@localhost procedure PromoteEmployee(IN p_cccd varchar(20))
BEGIN
    DECLARE v_username VARCHAR(50);

    -- Lấy tên đăng nhập của nhân viên từ cccd
    SELECT username INTO v_username
    FROM Employees
    WHERE cccd = p_cccd;

    -- Kiểm tra xem nhân viên có tồn tại không
    IF v_username IS NOT NULL THEN
        -- Thêm ROLE_MANAGER cho nhân viên
        INSERT IGNORE INTO UserRoles (username, role_id)
        VALUES (v_username, (SELECT role_id FROM Roles WHERE role_name = 'ROLE_MANAGER'));
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Nhân viên không tồn tại';
    END IF;
END;

